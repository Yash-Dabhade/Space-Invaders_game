import sys
from cx_Freeze import setup, Executable
setup(name="SpaceEnvaders", version="1.0", description="First game",
      executables=[Executable("main.py", base="Win32GUI")])
